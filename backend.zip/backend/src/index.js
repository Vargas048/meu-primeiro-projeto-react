const express = require('express');
const routes = require('./routes')
const app = express();

app.use(express.json());
app.use(routes);


/**
 *  Rota / Recurso
 */

/**
 * Métodos http:
 * 
 * Get: buscar uma informação do Back-end
 * Post: Criar uma informação no Back-end
 * Put: Alterar uma informação no Back-end
 * Delete: Deletar uma informação no Back-end
 *//**
Tipos de parâmetros

Query Params: Parametros nomeados enviados na rota após o sinbolo de "?" (filtros, Paginação)
Route Params: Parametros utilizados para identificar recursos 
Request Body: Corpo da requisição, utilizado para criar ou alterar recursos
*/

/**
 * SQL: MySQL, SQLite, PostgreSQ, Oracle, Microsoft SQL Server
 * NoSQL: MongoDB, CouchDB, etc
 */

/**
 * Driver: Select * FROM users
 * Query Builder: table('users').select('*').where()
 * 
 */


app.listen(3333);                           //pra assesar uma pasta no terminal coloca 'cd' antes burro.
